//#include "base_haeder.h"
#include "WorldMap.h"
#include "Character.h"

int main()
{

	map_area map1;

	map1.map_drawing();


}
